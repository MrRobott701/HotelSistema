<script>
	window.location='index.php?view=reserva';
</script>