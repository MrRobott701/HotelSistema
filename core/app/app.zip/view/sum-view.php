<?php 

require 'core/app/view/sumatoria-view.php';



?>

<tr>


	<td><center><b style="font-size: 20px;color:#16a085;">$    
    <?php echo number_format($pagadooo,0,'.',',');?></b></center></td>
<td><center><b style="font-size: 20px;color: #e05d6f;">$    
    <?php echo number_format($total_total,0,'.',',');?></b></center></td>
                                     
</tr>