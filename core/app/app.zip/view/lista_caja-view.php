
  <link rel="stylesheet" href="assets/js/vendor/datatables/css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="assets/js/vendor/datatables/datatables.bootstrap.min.css">
        <link rel="stylesheet" href="assets/js/vendor/datatables/extensions/ColReorder/css/dataTables.colReorder.min.css">
        <link rel="stylesheet" href="assets/js/vendor/datatables/extensions/Responsive/css/dataTables.responsive.css">
        <link rel="stylesheet" href="assets/js/vendor/datatables/extensions/ColVis/css/dataTables.colVis.min.css">
        <link rel="stylesheet" href="assets/js/vendor/datatables/extensions/TableTools/css/dataTables.tableTools.min.css">

<body id="minovate" class="appWrapper sidebar-sm-forced">
<div class="row">
<section class="content-header">
    <ol class="breadcrumb">
      <li><a href="index.php?view=reserva"><i class="fa fa-home"></i> Inicio</a></li>
      <li class="active"><a href="#">Lista de cajas</a></li>
    </ol>
</section> 

</div> 




<div id="reload-full-div">
	<div class="breadcrumb-line">
		
	  <div class="row">
		 <div class="breadcrumb col-lg-12">
				<div style="background-color: #16a085;color: white;padding: 2px;font-size: 20px;
				text-align: center; text-transform: uppercase;font-weight: bold;width: 100%;">
					<span>
					Registro de cajas</span>
			    </div>
	   	  </div>
	  </div>
	</div>
	<br> 
	 <div class="row">
		 <div class="col-sm-12 col-md-12">
		 	<form role="form" autocomplete="off" class="form-validate-jquery" id="" method="get">
        <div class="form-group">
          <div class="row">
            <div class="col-sm-2">
              <label>DESDE</label>

              <input type="hidden" name="view" value="lista_caja">
 
              <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                
                 <input type="date" name="desde" class="form-control" value="<?php 
              if(isset($_GET['desde']) and $_GET['desde']!=''){ echo $_GET['desde']; } ?>">
               </div>
            </div>
            <div class="col-sm-3">
              <label>HASTA</label>
              <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                <!--
                <input type="text" id="txtMes" name="txtMes" placeholder=""
                 class="form-control input-sm" style=""> -->
                 <input type="date" name="hasta" class="form-control" value="<?php 
              if(isset($_GET['hasta']) and $_GET['hasta']!=''){ echo $_GET['hasta']; } ?>">
               </div>
            </div>
            <div class="col-sm-4">
              <button style="margin-top: 27px;" id="btnGuardar" type="submit" class="btn btn-primary btn-sm"> 
              <i class="fa fa-search"></i> Consultar</button>
            </div>
          </div>
        </div>
        </form>
	   	  </div>
	  </div>


 






<!-- row --> 
<div class="row">
  <!-- col --> 
  <div class="col-md-12">
    <section class="tile">

             

           <div class="tile-body">
           

              <?php 
              if(isset($_GET['desde']) and $_GET['desde']!="" and isset($_GET['hasta']) and $_GET['hasta']!=""){
                $cajas = CajaData::getFiltroFechas($_GET['desde'],$_GET['hasta']);

              

                if(@count($cajas)>0){ 
                  // si hay usuarios
                  ?>
                  <div class="table-responsive">
                  <table class="table table-custom" id="editable-usage" style="font-size: 11px;">

                  <thead >
                        <th>Nro folio</th> 
                        <th>USUARIO</th>
                        <th>TURNO</th>
                        <th>FECHA APERTURA</th>
                        <th>FECHA CIERRE</th>
                        <th>MONTO</th>
                        <th></th>
                        
                  </thead>
                   <?php foreach($cajas as $caja):?>
                      <tr>
                        <td>#<?php echo $caja->id; ?></td>
                        <td><?php echo $caja->getUsuario()->name; ?></td>
                        <td><?php echo $caja->turno; ?></td>
                        <td><?php echo $caja->fecha_apertura; ?></td>
                        <td><?php echo $caja->fecha_cierre; ?></td>
                        <td><?php echo $caja->monto_cierre; ?></td>
                        <td> <a target="_blanck" href="reporte/pdf/documentos/pdf_caja.php?id=<?php echo $caja->id; ?>"  class="btn btn-success btn-xs"><i class="fa fa-eye"></i> </a></td>
                        
                      </tr> 
                           

<?php endforeach; ?>
                      
                  </table>
                </div>

               <?php }else{ 
            echo"<h4 class='alert alert-success'>NO HAY REGISTRO</h4>";

                }; };
                ?>

           </div>
</section>

</div>
</div>




    <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery/jquery-1.11.2.min.js"><\/script>')</script>
        <script src="assets/js/vendor/datatables/js/jquery.dataTables.min.js"></script>
        <script src="assets/js/vendor/datatables/extensions/dataTables.bootstrap.js"></script>
        <script>
          
            var table = $('#editable-usage').DataTable({
                language: {
                    "decimal": "",
                    "emptyTable": "No hay información",
                    "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
                    "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
                    "infoFiltered": "(Filtrado de _MAX_ total entradas)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "Mostrar _MENU_ Entradas",
                    "loadingRecords": "Cargando...",
                    "processing": "Procesando...",
                    "search": "Buscar:",
                    "zeroRecords": "Sin resultados encontrados",
                    "paginate": {
                        "first": "Primero",
                        "last": "Ultimo",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                },
               
            });

        </script>

        <!--/ Page Specific Scripts -->