  
<?php 
date_default_timezone_set('America/Santiago');
     $hoy = date("Y-m-d"); 

      $fechaaa = date("d/m/Y"); 
   $hora = date("H:i:s");
   $doce = date("12:00:00");

$nuevafecha = strtotime ( '+1 day' , strtotime ( $hoy ) ) ;
$nuevafecha = date ( 'Y-m-j' , $nuevafecha );



?>

<style type="text/css">
.nuevo {
    margin-top: 20px !important;
    margin-bottom: 20px !important;
}
.b-r {
    border-right: 3px solid rgba(0, 0, 0, 0.11) !important;
}
.table-bordered{
    font-size: 12px !important;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 4px !important;
}
.mb-10 {
    margin-bottom: 0px !important;
}
.p-10 {
    padding: 2px !important;
}
</style>
<?php 
    $cajas = CajaData::getAllAbierto(); 
    if(@count($cajas)>0){ $id_caja=$cajas->id;
    }else{$id_caja='NULL';}
?>

<div class="row" >
    <br>
    <div class="col-md-12">
    <!-- tile -->
        <section class="tile">

           

            <!-- tile body -->
            <div class="tile-body p-0">
                <div class="row">
                    <div class="col-md-12">
                        <form role="form" autocomplete="off" class="form-validate-jquery" id="enviarget" method="get">
                            <input type="hidden" name="view" value="lista_pasajeros">
                        <h2 style="text-decoration: underline;">Lista de pasajeros</h2>
                        <div class="col-md-3">
                            <div class="nuevo">
                                <div class="p-10 mb-10 event-control b-l b-2x b-greensea"> <b>Desde:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="date" required name="desde" style="line-height: 14px;" value="<?php 
              if(isset($_GET['desde']) and $_GET['desde']!=''){ echo date($_GET['desde']); } ?>">
                                </div>
                                <div class="p-10 mb-10 event-control b-l b-2x b-greensea"> <b>Hasta:</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input type="date" required name="hasta" style="line-height: 14px;" value="<?php if(isset($_GET['hasta']) and $_GET['hasta']!=''){echo $_GET['hasta'];} ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2" >
                            <div class="nuevo">
                                <div class="p-10 mb-10 event-control b-l b-2x b-greensea"> <b></b> 
                                    <div class="btn-group">
                                      <label>Todos los estados:</label>
                                      <div class="form-check">
                                          <input type="checkbox" class="form-check-input" id="checkin" name="checkin" value="checkin" <?php if(isset($_GET['checkin']) and $_GET['checkin']=='checkin'){ echo "checked"; } ?> ><label class="form-check-label" for="checkin">&nbsp;&nbsp;Check-in</label> 
                                      </div>
                                      <div class="form-check">
                                                <input type="checkbox" class="form-check-input" id="checkout" name="checkout" value="checkout"  <?php if(isset($_GET['checkout']) and $_GET['checkout']=='checkout'){ echo "checked"; } ?>  ><label class="form-check-label" for="checkout">&nbsp;&nbsp;Check-out</label>
                                      </div>

                                
                                </div>
                                </div>
                                
                            </div>
                        </div>

                        

                         <div class="col-md-3">
                            <div class="nuevo">
                                <div class="p-10 mb-10 event-control b-l b-2x b-greensea"> <b></b> 
                                  &nbsp;&nbsp;&nbsp;
                                    <button style="margin-top: 10px;"  id="btnGuardar" type="submit" class="btn btn-primary btn-sm"> 
                                      <i class="fa fa-search"></i> Consultar</button>
                                </div>
                                
                            </div>
                        </div>
                       

  

                        </form>
                       


                        

<div class="col-md-12" style="padding-top: 30px;">

        <?php if(isset($_GET['desde']) and $_GET['desde']!="" and isset($_GET['hasta']) and $_GET['hasta']!="" ){
               
                  ?>
                  <div class="table-responsive">
                  <table class="table table-custom" id="editable-usage" style="font-size: 11px;">

                  <thead >
                        <th><center>Folio</center></th>
                                    <th><center>Pieza</center></th>
                                    <th><center>Documento</center></th>
                                    <th><center>Nombre</center></th>
                                    <th><center>Pasajeros</center></th>
                                    <th><center>Fecha ingreso</center></th>
                                    <th><center>Estado</center></th>
                  </thead>
                   <?php 
                   if(isset($_GET['checkin']) and $_GET['checkin']=='checkin'){
                         $reportediarios = ProcesoData::getIngresoRangoFechasCheckin($_GET['desde'],$_GET['hasta']);
                   }else if(isset($_GET['checkout']) and $_GET['checkout']=='checkout'){
                         $reportediarios = ProcesoData::getIngresoRangoFechasCheckout($_GET['desde'],$_GET['hasta']);
                   }else{
                        $reportediarios = ProcesoData::getIngresoRangoFechas($_GET['desde'],$_GET['hasta']);
                   }
                   

                    if(@count($reportediarios)>0){  ?>
                         <?php foreach($reportediarios as $reportediario):


                            ?>
                    <tr>
                   
                        <td><a href="index.php?view=addprocesoprueba&id=<?php echo $reportediario->id; ?>"><?php echo $reportediario->nro_folio; ?></a></td>
                        <td><?php echo $reportediario->getHabitacion()->nombre; ?></td>
                        <td><?php echo $reportediario->getCliente()->documento; ?></td>
                        <td><?php echo $reportediario->getCliente()->nombre; ?></td>
                        <td><?php echo $reportediario->pasajero; ?></td>
                        <td><?php echo $reportediario->fecha_entrada; ?></td>
                        <td><?php if($reportediario->estado=='0'){ echo "Check-in";}else if($reportediario->estado=='1'){ echo "Check-out";} ?></td>
                    </tr>
                        
                     
                    <?php endforeach; ?>

                    <?php  }; ?>
                      
                  </table>
                </div>

                <?php  }; ?>

                           

                            
            </div>

                       




                    </div>
                </div>

            </div>
            <!-- /tile body -->

        </section>
        <!-- /tile --> 
        <hr><hr><hr><hr><hr>
    </div>

<script src="js/filtro/slim.js"></script>
<script src="js/filtro/jquery.js"></script>
<script src="js/filtro/poper.js"></script>
<script src="js/filtro/bostr.js"></script>

<script type="text/javascript">
    $(function ()
{
    get_users();

    $(".form-check-input").on("click", function ()
    {
        get_users();
    });

});

function get_users()
{

    let form = $("#multi-filters");

    $.ajax(
        {
            type: "POST",
            url: "index.php?action=filtro_gasto",
            data: form.serialize(),
            success: function (data)
            {
                $("#filters-result").html("");


                $.each(JSON.parse(data), function(key, Gasto)
                {
                    var estado=Gasto.estado;
                    if(estado=='1'){ var newestado="Egreso";}else{ var newestado="Ingreso";}
                    let row = ""+
                        "<tr>"+ 
                        "<td>"+ newestado +"</td> " + 
                        "<td>"+Gasto.modulo+"</td> " +
                        "<td>"+Gasto.categoria+"</td> " +
                        "<td>"+Gasto.descripcion+"</td> " +
                        "<td>"+Gasto.fecha+"</td> " +
                        "<td>"+Gasto.precio+"</td> " +
                        "</tr>";

                    $("#filters-result").append(row);


                });

            }
        }
    )
}
</script>


