              
<?php if(isset($_POST['id']) and $_POST['id']!=""){ ?>

<?php $tarifa = TarifaData::getById($_POST['id']); ?>          
                
                <div class="form-group col-md-4 mb-0">
                    <label for="pr-subject">Precio: </label>
                    <div class="input-group">

                      <input type="hidden" class="form-control monto" name="precio_a"  value="<?php echo $tarifa->precio; ?>" >

                      <input type="number" class="form-control monto" name="precio" placeholder="Ingrese precio" value="<?php echo $tarifa->precio; ?>" onkeyup="sumar();" onchange="sumar();" id="precio" readonly>
                      <span class="input-group-btn" id="resultados">
                          <a href="#"  data-toggle="modal" data-target="#confirmarcambio" data-options="splash-2 splash-ef-11" class="tex-danger btn-xs b-0" style="color:#e05d6f;"><i class="glyphicon glyphicon-lock"></i></a>
                      </span>
                    </div>
                </div>

                <script type="text/javascript">           
                $(document).ready(function(){

                  const min = 1;    // Valor mínimo
                  const max = 20; // Valor máximo
                  $(document).on('keyup', '#cant_noche', function(){
                    var self = $(this);
                    var value = self.val();
                    
                    if(value < min || value > max){
                      self.val('');
                    }
                    
                  })

                });
                </script>   



                <div class="form-group col-md-4 mb-0">
                    <label for="pr-subject"> Cant. noches: </label>
                    <input type="number" class="form-control monto" required="" name="cant_noche" id="cant_noche" min="1" max="20" value="1" onkeyup="sumar();" onchange="sumar();" >
                </div>
                    
                

                <!--
                <div class="input-group"> 
                  <div class="input-group-addon">
                    <i class="fa fa-money"></i> Persona extra&nbsp;&nbsp;&nbsp;
                  </div>
                -->
                  <input type="hidden" class="form-control monto" style="border-color: red;" name="extra" placeholder="Ingrese precio" value="0" onkeyup="sumar();" onchange="sumar();" id="extra">

                <!--  
                </div>
              -->
                <!-- /.input group -->
                <div class="input-group"> 
               
                  <h2 style="font-size: 18px;font-weight: bold;color: #51445f;"><span>Total a pagar: </span> <span id="spTotal" ><?php echo $tarifa->precio*1; ?></span></h2>
                
                
                </div>


<?php }; ?>